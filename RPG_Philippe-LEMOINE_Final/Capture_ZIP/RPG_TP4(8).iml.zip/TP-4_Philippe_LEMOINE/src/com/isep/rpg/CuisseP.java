package com.isep.rpg;

public class CuisseP extends Food{
    public CuisseP(String name) {
        super(name);
        mana = 5;
        quantitee = 20;
        quantiteeM = 20;
    }
}
