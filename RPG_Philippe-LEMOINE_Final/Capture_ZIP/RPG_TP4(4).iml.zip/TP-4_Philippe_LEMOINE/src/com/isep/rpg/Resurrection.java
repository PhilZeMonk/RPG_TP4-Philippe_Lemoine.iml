package com.isep.rpg;

public class Resurrection extends Sort{
    public Resurrection(String name) {
        super(name);
        coutS = 5;
        healthPointS = 40;
    }
}