public class CombattantTest {
}
