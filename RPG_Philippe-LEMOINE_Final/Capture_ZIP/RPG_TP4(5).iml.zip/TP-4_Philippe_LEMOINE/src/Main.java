import java.util.Scanner;

import com.isep.rpg.*;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Game game = new Game(null);
        game.start();
    }
}