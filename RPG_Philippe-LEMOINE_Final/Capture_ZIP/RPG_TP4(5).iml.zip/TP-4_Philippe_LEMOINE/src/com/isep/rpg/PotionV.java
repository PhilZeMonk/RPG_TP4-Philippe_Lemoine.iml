package com.isep.rpg;

public class PotionV extends Potion{
    public PotionV(String name) {
        super(name);
        int recupVie = 70;
        this.recupVie = recupVie;
        quantitee = 4;
        quantiteeM = 4;
    }
}
