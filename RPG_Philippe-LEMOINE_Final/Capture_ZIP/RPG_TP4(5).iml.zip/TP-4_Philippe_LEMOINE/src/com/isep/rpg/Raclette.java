package com.isep.rpg;

public class Raclette extends Food{
    public Raclette(String name) {
        super(name);
        mana = 10;
        quantitee = 10;
        quantiteeM = 10;
    }
}
