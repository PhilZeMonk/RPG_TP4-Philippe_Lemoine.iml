package com.isep.rpg;

public abstract class Sort extends Item{
    public Sort(String name) {
        super(name);
    }

    public int effetS;
    public int degat;
    public int coutS;
    public int healthPointS;
    public int rS;
    public int rP;
}
