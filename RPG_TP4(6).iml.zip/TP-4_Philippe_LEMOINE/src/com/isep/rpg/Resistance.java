package com.isep.rpg;

public class Resistance extends Sort{
    public Resistance(String name) {
        super(name);
        coutS = 1;
        rS = 2;
        rP = 2;
    }
}
