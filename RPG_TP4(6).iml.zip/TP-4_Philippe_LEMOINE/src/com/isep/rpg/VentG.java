package com.isep.rpg;

public class VentG extends Sort{
    public VentG(String name) {
        super(name);
        coutS = 3;
        degat = 30;
        effetS = 10;;
    }
}
