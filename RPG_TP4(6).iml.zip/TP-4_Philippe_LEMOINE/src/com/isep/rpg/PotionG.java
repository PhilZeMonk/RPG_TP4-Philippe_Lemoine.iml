package com.isep.rpg;

public class PotionG extends Potion {
    public PotionG(String name) {
        super(name);
        int effet = 0;
        this.effet = effet;
        quantitee = 4;
        quantiteeM = 4;
    }
}
