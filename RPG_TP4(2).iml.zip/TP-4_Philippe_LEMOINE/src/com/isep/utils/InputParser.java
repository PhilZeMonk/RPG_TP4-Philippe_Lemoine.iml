package com.isep.utils;

public class InputParser {
}
