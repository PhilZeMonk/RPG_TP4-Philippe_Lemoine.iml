package com.isep.rpg;

public class Retour extends Sort{
    public Retour(String name) {
        super(name);
        coutS = 0;
    }
}
