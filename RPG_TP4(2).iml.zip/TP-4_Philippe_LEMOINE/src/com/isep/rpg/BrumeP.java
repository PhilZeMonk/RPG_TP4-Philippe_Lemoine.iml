package com.isep.rpg;

public class BrumeP extends Sort{
    public BrumeP(String name) {
        super(name);
        coutS = 2;
        degat = 25;
        effetS = 15;
    }
}
