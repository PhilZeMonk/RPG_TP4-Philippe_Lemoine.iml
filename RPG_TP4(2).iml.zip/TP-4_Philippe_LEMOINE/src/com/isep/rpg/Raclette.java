package com.isep.rpg;

public class Raclette extends Food{
    public Raclette(String name) {
        super(name);
        int mana = 10;
        this.mana = mana;
        quantitee = 10;
        quantiteeM = 10;
    }
}
