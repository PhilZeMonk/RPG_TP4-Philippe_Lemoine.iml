package com.isep.rpg;

public class PotionR extends Potion{
    public PotionR(String name) {
        super(name);
        int resistance = 2;
        this.resistance = resistance;
        quantitee = 4;
        quantiteeM = 4;
    }
}
