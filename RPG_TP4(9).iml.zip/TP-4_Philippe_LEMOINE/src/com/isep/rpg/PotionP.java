package com.isep.rpg;

public class PotionP extends Potion{
    public PotionP(String name) {
        super(name);
        int poison = 5;
        this.poison = poison;
        quantitee = 4;
        quantiteeM = 4;
    }
}
