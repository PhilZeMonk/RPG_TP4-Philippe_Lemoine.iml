package com.isep.rpg;

import com.isep.utils.InputParser;

import javax.rmi.ssl.SslRMIClientSocketFactory;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class Game {
    private boolean VF;
    public static Hero[] hero;
    public static Ennemy[] ennemis;
    public static Potion[] potion;
    public static Food[] food;
    public static Sort[] sortM;
    public static Sort[] sortG;
    public static Sort[] sortC;
    static int nH;
    static int nE;
    static int nbTour;
    int niveau;
    boolean Ko = false;
    boolean pasKo = true;

    public Game(InputParser inputParser) {

        this.inputParser = inputParser;
    }

    public void start() throws InterruptedException {
        System.out.println("Bienvenue dans le meilleur RPG du monde");
        TimeUnit.SECONDS.sleep(1);
        System.out.println("Initialisation des paramètres");
        TimeUnit.SECONDS.sleep(1);
        System.out.print("Création de votre équipe");
        TimeUnit.SECONDS.sleep(1);
        System.out.print(".");
        TimeUnit.SECONDS.sleep(1);
        System.out.print(".");
        TimeUnit.SECONDS.sleep(1);
        System.out.println(".");
        TimeUnit.SECONDS.sleep(1);
        System.out.println("Voici l'équipe qui sauvera le monde:");
        nombreHero();
        afficheHero();
        System.out.println(" ");
        System.out.println("#########################################");
        System.out.println(" ");
        System.out.println("###### Description de votre sac de départ ######");
        System.out.println(" ");
        sac();
        TimeUnit.SECONDS.sleep(1);
        nbTour = nbTour();
        for (int i = 0; i < nbTour; i++){
            boolean etatH = KoA();
            if (etatH == pasKo){
                System.out.println("#########################################");
                TimeUnit.SECONDS.sleep(1);
                System.out.println("Attention, il y a des mouvements dans les hautes herbes, vite allons voir...");
                TimeUnit.SECONDS.sleep(3);
                System.out.println("Oh non, c'est une embuscade, les ennemis vous encerclent");
                TimeUnit.SECONDS.sleep(1);
                System.out.println("Voici vos adversaires");
                nbEnnemis();
                afficheEnnemies();
                TimeUnit.SECONDS.sleep(1);
                System.out.println(" ");
                combat(ennemis);
                System.out.println(" ");
                System.out.println("Fin du Tour " + (i+1) + " / " + nbTour);
                finCombatH();
            }
        }
        finJeu();
    }

    public Hero[] nombreHero() {
        String YN;
        String n;
        String cl;

        do {
            Scanner scanner1 = new Scanner(System.in);
            System.out.println("Veuillez saisir le nombre de héros dans votre équipe:");
            nH = scanner1.nextInt(); //Attention, il faut vérifier que c un bien un int
            VF = msgDebut(nH);
            if (VF == true){
                System.out.println("Il y a " + nH + " membres dans votre équipe.");
                System.out.println("Est-ce exact?");
                YN = scanner1.next();
            }
            else{
                System.out.println("Une équipe comporte 5 héros maximum.");
                YN = "n";
            }
        } while (!YN.equalsIgnoreCase("y"));
        this.hero = new Hero[nH];
        this.hero[0] = new Warrior("toto");
        for (int i = 0; i < nH; i++) {
            int j = (i + 1);
            do {
                Scanner scanner2 = new Scanner(System.in);
                System.out.println("Veuillez saisir le nom du héros " + j + " de votre équipe:");
                n = scanner2.next();
                System.out.println("Le héro " + j + " de votre équipe s'appelle " + n);
                System.out.println("Est-ce exact?");
                YN = scanner2.next();
            } while (!YN.equalsIgnoreCase("y"));
            do {
                Scanner scanner3 = new Scanner(System.in);
                System.out.println("Veuillez saisir la classe du héros " + j + " de votre équipe (c pour chevalier, a pour archer, m pour mage, g pour guerisseur):");
                cl = scanner3.next();
                System.out.println("Le héro " + j + " de votre équipe est de classe " + cl);
                System.out.println("Est-ce exact?");
                YN = scanner3.next();
            } while (!YN.equalsIgnoreCase("y"));
            switch (cl) {
                case "c":
                    hero[i] = new Warrior(n);
                    hero[i].take(new Weapon("Épée"));
                    break;
                case "a":
                    hero[i] = new Hunter(n);
                    hero[i].take(new Weapon("Arc"));
                    break;
                case "m":
                    hero[i] = new Mage(n);
                    hero[i].take(new Weapon("Bâton de sorcier"));
                    break;
                case "g":
                    hero[i] = new Healer(n);
                    hero[i].take(new Weapon("Baguette"));
                    break;
            }
        }
        return hero;
    }

    public void sac(){
        potion = new Potion[4];
        potion[0] = new PotionV("Potion de Vie");
        System.out.println("Potion de vie: régénère 70 HP");
        potion[1] = new PotionR("Potion de Résistance");
        System.out.println("Potion de résistance: réduit de 50% les dégâts énnemis");
        potion[2] = new PotionP("Potion de Poison");
        System.out.println("Potion de poison: empoisonne l'ennemi, celui-ci perdra 5 HP par tour tant qu'il ne sera pas guerri");
        potion[3] = new PotionG("Potion de Guérison");
        System.out.println("Potion de guérison: annule tous les effets");

        food = new Food[2];
        food[0] = new CuisseP("Cuisse de Poulet");
        food[1] = new Raclette("Raclette");
    }

    public Ennemy[] nbEnnemis(){
        int i = 0;
        int j = 0;

        int typeEnnemi = typeEnnemi();
        niveau = niveau();

        if(typeEnnemi == 1){
            nE = nE(nH);
        }
        else if (typeEnnemi == 2){
            nE = nE(nH);
            if (nE > 1){
                nE--;
            }
        }
        else{
            if (nH == 1){
                nE = 1;
            }
            else{
                nE = nE(1);
                if (nE > nH){
                    nE = nH;
                }
            }
        }

        ennemis = new Ennemy[nE];

        if (typeEnnemi == 1){
            if (niveau == 2){
                ennemis[0] = new Gnome("Gnome (Boss)", 2);
                for (i = 1; i < nE; i++){
                    ennemis[i] = new Gnome("Gnome " + i, 1);
                }
            }
            else{
                for (i = 0; i < nE; i++){
                    ennemis[i] = new Gnome("Gnome " + (i+1), 1);
                }
            }
        }
        else if (typeEnnemi == 2){
            if (niveau == 2){
                ennemis[0] = new Troll("Troll (Boss)", 2);
                for (i = 1; i < nE; i++){
                    ennemis[i] = new Troll("Troll " + i, 1);
                }
            }
            else{
                for (i = 0; i < nE; i++){
                    ennemis[i] = new Troll("Troll " + (i+1), 1);
                }
            }
        }
        else{
            if (niveau == 2){
                ennemis[0] = new Dragon("Dragon (Boss)", 2);
                for (i = 1; i < nE; i++){
                    ennemis[i] = new Dragon("Dragon " + i, 1);
                }
            }
            else{
                for (i = 0; i < nE; i++){
                    ennemis[i] = new Dragon("Dragon " + (i+1), 1);
                }
            }
        }
        return ennemis;
    }

    public boolean msgDebut(int nH){
        boolean VF;

        if (nH < 6){
            VF = true;
        }
        else{
            VF = false;
        }
        return VF;
    }

    public void afficheHero(){
        for (int i = 0; i < nH; i++){
            System.out.println(hero[i].name + " | " + hero[i].healthPoint + " HP | " + hero[i].mana + " mana");
        }
    }

    public void afficheEnnemies(){
        for (int i = 0; i<nE; i++){
            System.out.println(ennemis[i].name + " | " + ennemis[i].healthPoint + " HP");
        }
    }

    public int typeEnnemi(){
        Random rand = new Random();
        int type0;
        return type0 = 1 + rand.nextInt(3);
    }

    public int niveau(){
        Random rand = new Random();
        int niveau;
        return niveau = 1 + rand.nextInt(2);
    }

    public int nE (int nH){
        Random rand = new Random();
        return nE = 1 + rand.nextInt(nH + 2);
    }

    public int nbTour(){
        Random tour = new Random();
        return nbTour = 1 + tour.nextInt(4);
    }

    private InputParser inputParser;
    public static void displayStatus() {
        System.out.println("#################################");
        System.out.println(" ");
        int i;
        int j;
        System.out.println("Votre équipe:");
        for (i = 0; i < nH; i++) {
            System.out.println(hero[i].name + " (" + hero[i].healthPoint + " HP) ");
        }
        System.out.println(" ");
        System.out.println("----------------VS-----------------");
        System.out.println(" ");
        System.out.println("L'équipe adversaire:");
        for (j = 0; j < nE; j++) {
            System.out.println(ennemis[j].name + " (" + ennemis[j].healthPoint + " HP) ");
        }
        System.out.println();
    }

    public static void finCombatH(){
        System.out.println("#################################");
        System.out.println(" ");
        int i;
        System.out.println("Votre équipe:");
        for (i = 0; i < nH; i++) {
            System.out.println(hero[i].name + " (" + hero[i].healthPoint + " HP) ");
        }
    }

    public void combat(Ennemy [] ennemisC) throws InterruptedException {
        int i = 0;
        boolean KoA = KoA();
        boolean KoE = KoE();
        String ON;
        String YN;
        while ((KoA == pasKo) & (KoE == pasKo)){   //KoA = true et KoE = true...
            i++;
            while(KoE == pasKo){
                tourAl(hero, ennemisC);
            }

            if (KoE == pasKo){
                for (i = 0; i < nE; i++){
                    if (ennemisC[i].healthPoint != 0) {
                        attaqueEn(ennemisC);
                    }
                }
            }

            etatAl(hero);
            etatEn(ennemisC);
        }

        if (!KoE){
            System.out.println("L'équipe adverse est KO");
            System.out.println("Vous avez gagné");
            loot();
            experience();
        }

        else{
            System.out.println("Votre équipe est KO");
            System.out.println("Vous étiez notre dernier espoir");
            System.out.println("Le Monde va être annéanti");
            System.out.println("À moins qu'un nouvel espoir apparait");

            Scanner scanner = new Scanner(System.in);
            System.out.println("Voulez-vous retenter l'aventure? (o pour oui, n pour non)");
            ON = scanner.next();

            if (ON == "o"){
                System.out.println("En êtes-vous sûr?");
                YN = scanner.next();

                if (YN == "y"){
                    start();
                }
            }
        }
    }

    private boolean KoA() {
        boolean KOA = pasKo;
        for (int i = 0; i < nH; i++){
            if (hero[i].healthPoint != 0){
                KOA = pasKo;
            }
            else{
                KOA = Ko;
            }
        }
        return KOA;
    }

    private boolean KoE() {
        boolean KOE = pasKo;
        for (int i = 0; i < nE; i++){
            if (ennemis[i].healthPoint != 0){
                KOE = pasKo;
            }
            else{
                KOE = Ko;
            }
        }
        return KOE;
    }

    public void tourAl(Hero[] hero0, Ennemy [] ennemi0){
        for (int i = 0; i < nH; i++){
            displayStatus();
            action(hero0[i],hero0,ennemi0);
        }
    }

    public void action(Hero hero01, Hero[] hero02, Ennemy [] ennemi01){
        if (hero01.healthPoint != 0){
            int actR = tourAl1(hero01);
            switch (actR){
                case 10:
                    attaqueHe(hero01, ennemi01);
                    break;
                case 20:
                    protegeHe(hero01);
                    break;
                case 30:
                    sortilege(hero01, hero02, ennemi01);
                    break;
                case 41:
                    nourritureH(hero01, hero02, ennemi01);
                    break;
                case 42:
                    potionH(hero01, hero02, ennemi01);
                    break;
                case 43:
                    tourAl1(hero01);
                    break;

            }
        }
    }

    public int tourAl1(Hero hero1) {
        String name = hero1.name;
        Scanner tour = new Scanner(System.in);
        Scanner item = new Scanner(System.in);
        System.out.println("Que va faire " + name + ":");
        System.out.println("1) Attaquer");
        System.out.println("2) Se protéger");
        System.out.println("3) Sortilège");
        System.out.println("4) Items");
        int action = tour.nextInt(); //vérifier que c'est un int et que 0<action<=4
        int items=0;

        switch (action) {
            case 1:
                break;
            case 2:
                break;
            case 3:

                break;
            case 4:
                System.out.println("Quel item va-t-il prendre?");
                System.out.println("1) Nourriture");
                System.out.println("2) Potion");
                System.out.println("3) Retour");
                items = tour.nextInt();
                break;
        }
        int act = action * 10 + items; //act = 10 (attaque), 20 (défense), 30 (sort), 41 (nourriture), 42 (potion), 43 (AL1)
        return act;
    }

    public void attaqueHe(Hero heroAt, Ennemy[] ennemiA){
        int getDamage = heroAt.degP * heroAt.weapon.getDamagePoints();
        Scanner attaquer = new Scanner(System.in);
        System.out.println("Qui voulez-vous attaquer?");
        afficheEnnemies();
        int attaque = attaquer.nextInt() - 1;
        if (attaque < nE){ //nE_i = nE pour ennemis-i, faire nE-- pour n'avoir que les ennemis encore en vie.
            System.out.println(heroAt.name + " attaque l'ennemi " + ennemiA[attaque].name);
            if (getDamage > ennemiA[attaque].healthPoint){
                ennemiA[attaque].healthPoint = 0;
            }
            else {
                ennemiA[attaque].healthPoint -= getDamage;
            }
        }
    }

    public void protegeHe(Hero heroD){
        System.out.println(heroD.name + " se défend.");
        heroD.degP = heroD.degP * 2;
    }

    public void sortilege(Hero heroSo, Hero[] heroS, Ennemy[] ennemiSo){
        Scanner sorts = new Scanner(System.in);
        sortM = new Sort[5];
        sortM[0] = new Boul2Feu("Boule de feu");
        sortM[1] = new Soins("Soins");
        sortM[2] = new BrumeP("Brume de Poison");
        sortM[3] = new VentG("Vent Glacial");
        sortM[4] = new Retour("Retour");

        sortG = new Sort[5];
        sortG[0] = new Boul2Feu("Boule de feu");
        sortG[1] = new Soins("Soins");
        sortG[2] = new Resistance("Résistance");
        sortG[3] = new Resurrection("Résurrection");
        sortG[4] = new Retour("Retour");

        sortC = new Sort[3];
        sortC[0] = new Boul2Feu("Boule de feu");
        sortC[1] = new Soins("Soins");
        sortC[2] = new Retour("Retour");

        int sort;
        int qui;
        System.out.println("Quel sort " + heroSo.name + " va-t-il lancer?");
        if (heroSo.classe.equals("Mage")){
            do{
                afficheSortM();
                sort = sorts.nextInt();
                if (heroSo.mana < sortM[sort-1].coutS){
                    System.out.println(heroSo.name + " n'a pas assez de mana pour lancer ce sort");
                    System.out.println("Veuillez choisir un nouveau sort");
                }
            } while (heroSo.mana < sortM[sort-1].coutS);

            if (sort == 1){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheEnnemies();
                    System.out.println("(insérer la position du monstre que vous voulez attaquer)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nE){
                        System.out.println("Il n'y a aucun monstre à attaquer ici, veuillez sélectionner un nouveau monstre");
                    }
                    else{
                        if (ennemiSo[qui].healthPoint == 0){
                            System.out.println("Le monstre est KO, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nE & ennemiSo[qui].healthPoint == 0) || (qui == 0 || qui > nE));
                sortM[sort-1].effetS = 15;
                System.out.println(heroSo.name + " lance une " + sortM[sort-1].name + " sur " + ennemiSo[qui].name);
                if (ennemiSo[qui].healthPoint < sortM[sort-1].degat){
                    ennemiSo[qui].healthPoint = 0;
                }
                else{
                    ennemiSo[qui].healthPoint -= sortM[sort-1].degat;
                    ennemiSo[qui].effet += sortM[sort-1].effetS;
                }
            }

            else if (sort == 2){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheHero();
                    System.out.println("(insérer la position du héro que vous voulez soigner)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nH){
                        System.out.println("Il n'y a aucun héro à soigner ici, veuillez sélectionner un nouveau héro");
                    }
                    else{
                        if (heroS[qui].healthPoint == 0){
                            System.out.println("Le héro est KO, veuillez sélectionner un nouveau monstre");
                        }
                        else if (heroS[qui].healthPoint == heroS[qui].healthPointMax){
                            System.out.println("Le héro a déjà toute sa vie au max, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nH & heroS[qui].healthPoint == 0 & heroS[qui].healthPoint >= heroS[qui].healthPointMax)|| (qui ==0 || qui > nH));
                sortM[sort-1].healthPointS = 50;
                System.out.println(heroSo.name + " utilise un " + sortM[sort-1].name + " sur " + heroS[qui].name);
                if (heroS[qui].healthPointMax - heroS[qui].healthPoint < sortM[sort-1].healthPointS){
                    heroS[qui].healthPoint = heroS[qui].healthPointMax;
                }
                else{
                    heroS[qui].healthPoint += sortM[sort-1].healthPointS;
                }
            }

            else if (sort == 3){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheEnnemies();
                    System.out.println("(insérer la position du monstre que vous voulez attaquer)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nE){
                        System.out.println("Il n'y a aucun monstre à attaquer ici, veuillez sélectionner un nouveau monstre");
                    }
                    else{
                        if (ennemiSo[qui].healthPoint == 0){
                            System.out.println("Le monstre est KO, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nE & ennemiSo[qui].healthPoint == 0) || (qui == 0 || qui > nH));
                System.out.println(heroSo.name + " lance une " + sortM[sort-1].name + " sur " + ennemiSo[qui].name);
                if (ennemiSo[qui].healthPoint < sortM[sort-1].degat){
                    ennemiSo[qui].healthPoint = 0;
                }
                else{
                    ennemiSo[qui].healthPoint -= sortM[sort-1].degat;
                    ennemiSo[qui].effet += sortM[sort-1].effetS;
                }
            }

            else if (sort == 4){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheEnnemies();
                    System.out.println("(insérer la position du monstre que vous voulez attaquer)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nE){
                        System.out.println("Il n'y a aucun monstre à attaquer ici, veuillez sélectionner un nouveau monstre");
                    }
                    else{
                        if (ennemiSo[qui].healthPoint == 0){
                            System.out.println("Le monstre est KO, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nE & ennemiSo[qui].healthPoint != 0) || (qui == 0 || qui > nH));
                System.out.println(heroSo.name + " lance un " + sortM[sort-1].name + " sur " + ennemiSo[qui].name);
                if (ennemiSo[qui].healthPoint < sortM[sort-1].degat){
                    ennemiSo[qui].healthPoint = 0;
                }
                else{
                    ennemiSo[qui].healthPoint -= sortM[sort-1].degat;
                    ennemiSo[qui].effet += sortM[sort-1].effetS;
                }
            }

            else{
                action(heroSo,heroS,ennemiSo);
            }
        }

        else if (heroSo.classe.equals("Healer")){
            do{
                afficheSortG();
                sort = sorts.nextInt();
                if (heroSo.mana < sortM[sort-1].coutS){
                    System.out.println(heroSo.name + " n'a pas assez de mana pour lancer ce sort");
                    System.out.println("Veuillez choisir un nouveau sort");
                }
            } while (heroSo.mana < sortG[sort-1].coutS);

            if (sort == 1){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheEnnemies();
                    System.out.println("(insérer la position du monstre que vous voulez attaquer)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nE){
                        System.out.println("Il n'y a aucun monstre à attaquer ici, veuillez sélectionner un nouveau monstre");
                    }
                    else{
                        if (ennemiSo[qui].healthPoint == 0){
                            System.out.println("Le monstre est KO, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nE & ennemiSo[qui].healthPoint == 0) || (qui == 0 || qui > nE));
                sortG[sort-1].effetS = 5;
                System.out.println(heroSo.name + " lance une " + sortG[sort-1].name + " sur " + ennemiSo[qui].name);
                if (ennemiSo[qui].healthPoint < sortG[sort-1].degat){
                    ennemiSo[qui].healthPoint = 0;
                }
                else{
                    ennemiSo[qui].healthPoint -= sortG[sort-1].degat;
                    ennemiSo[qui].effet += sortG[sort-1].effetS;
                }
            }

            else if (sort == 2){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheHero();
                    System.out.println("(insérer la position du héro que vous voulez soigner)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nH){
                        System.out.println("Il n'y a aucun héro à soigner ici, veuillez sélectionner un nouveau héro");
                    }
                    else{
                        if (heroS[qui].healthPoint == 0){
                            System.out.println("Le héro est KO, veuillez sélectionner un nouveau monstre");
                        }
                        else if (heroS[qui].healthPoint == heroS[qui].healthPointMax){
                            System.out.println("Le héro a déjà toute sa vie au max, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nH & (heroS[qui].healthPoint == 0 & heroS[qui].healthPoint == heroS[qui].healthPointMax)) || (qui < 0 || qui > nH));
                sortG[sort-1].healthPointS = 50;
                System.out.println(heroSo.name + " utilise un " + sortG[sort-1].name + " sur " + heroS[qui].name);
                if (heroS[qui].healthPointMax - heroS[qui].healthPoint < sortG[sort-1].healthPointS){
                    heroS[qui].healthPoint = heroS[qui].healthPointMax;
                }
                else{
                    heroS[qui].healthPoint += sortG[sort-1].healthPointS;
                }
            }

            else if (sort == 3){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheHero();
                    System.out.println("(insérer la position du héro que vous voulez protéger)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nH){
                        System.out.println("Il n'y a aucun héro à protéger ici, veuillez sélectionner un nouveau héro");
                    }
                    else{
                        if (heroS[qui].healthPoint == 0){
                            System.out.println("Le héro est KO, veuillez sélectionner un nouveau héro");
                        }
                    }
                } while ((qui > 0 & qui <= nH & heroS[qui].healthPoint == 0) || (qui==0 || qui > nH));
                heroS[qui].resP = heroS[qui].resP*2;
                heroS[qui].resS = heroS[qui].resS*2;
            }

            else if (sort == 4){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheHero();
                    System.out.println("(insérer la position du héro que vous voulez ressusciter)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nH){
                        System.out.println("Il n'y a aucun héro à soigner ici, veuillez sélectionner un nouveau héro");
                    }
                    else{
                        if (heroS[qui].healthPoint != 0){
                            System.out.println("Le héro n'est pas KO, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nH & heroS[qui].healthPoint != 0) || (qui < 0 || qui > nH));
                sortG[sort-1].healthPointS = 50;
                System.out.println(heroSo.name + " utilise un " + sortG[sort-1].name + " sur " + heroS[qui].name);
                if (heroS[qui].healthPointMax - heroS[qui].healthPoint < sortG[sort-1].healthPointS){
                    heroS[qui].healthPoint = heroS[qui].healthPointMax;
                }
                else{
                    heroS[qui].healthPoint += sortG[sort-1].healthPointS;
                }
            }

            else{
                action(heroSo,heroS,ennemiSo);
            }
        }

        else {
            do{
                afficheSortC();
                sort = sorts.nextInt();
                if (heroSo.mana < sortM[sort-1].coutS){
                    System.out.println(heroSo.name + " n'a pas assez de mana pour lancer ce sort");
                    System.out.println("Veuillez choisir un nouveau sort");
                }
            } while (heroSo.mana < sortC[sort-1].coutS);

            if (sort == 1){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheEnnemies();
                    System.out.println("(insérer la position du monstre que vous voulez attaquer)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nE){
                        System.out.println("Il n'y a aucun monstre à attaquer ici, veuillez sélectionner un nouveau monstre");
                    }
                    else{
                        if (ennemiSo[qui].healthPoint == 0){
                            System.out.println("Le monstre est KO, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nE & ennemiSo[qui].healthPoint == 0) || (qui <= 0 || qui > nE));
                sortC[sort-1].effetS = 5;
                System.out.println(heroSo.name + " lance une " + sortC[sort-1].name + " sur " + ennemiSo[qui].name);
                if (ennemiSo[qui].healthPoint < sortC[sort-1].degat){
                    ennemiSo[qui].healthPoint = 0;
                }
                else{
                    ennemiSo[qui].healthPoint -= sortC[sort-1].degat;
                    ennemiSo[qui].effet += sortC[sort-1].effetS;
                }
            }

            else if (sort == 2){
                System.out.println("Sur qui voulez-vous lancer ce sort?");
                do{
                    afficheHero();
                    System.out.println("(insérer la position du héro que vous voulez soigner)");
                    qui = sorts.nextInt();
                    if (qui <1 || qui > nH){
                        System.out.println("Il n'y a aucun héro à soigner ici, veuillez sélectionner un nouveau héro");
                    }
                    else{
                        if (heroS[qui].healthPoint == 0){
                            System.out.println("Le héro est KO, veuillez sélectionner un nouveau monstre");
                        }
                        else if (heroS[qui].healthPoint == heroS[qui].healthPointMax){
                            System.out.println("Le héro a déjà toute sa vie au max, veuillez sélectionner un nouveau monstre");
                        }
                    }
                } while ((qui > 0 & qui <= nH & (heroS[qui].healthPoint == 0 || heroS[qui].healthPoint == heroS[qui].healthPointMax)) || (qui == 0 || qui > nH));
                sortC[sort-1].healthPointS = 20;
                System.out.println(heroSo.name + " utilise un " + sortC[sort-1].name + " sur " + heroS[qui].name);
                if (heroS[qui].healthPointMax - heroS[qui].healthPoint < sortC[sort-1].healthPointS){
                    heroS[qui].healthPoint = heroS[qui].healthPointMax;
                }
                else{
                    heroS[qui].healthPoint += sortC[sort-1].healthPointS;
                }
            }

            else{
                action(heroSo,heroS,ennemiSo);
            }
        }
    }

    public void afficheSortM(){
        for (int i = 0; i < 4; i++){
            if (sortM[i].coutS == 0){
                System.out.println((i+1) + " " +sortM[i].name);
            }
            else{
                System.out.println((i+1) + " " +sortM[i].name + " | " + sortM[i].coutS + " mana");
            }
        }
    }

    public void afficheSortG(){
        for (int i = 0; i < 4; i++){
            if (sortG[i].coutS == 0){
                System.out.println((i+1) + " " +sortG[i].name);
            }
            else{
                System.out.println((i+1) + " " +sortG[i].name + " | " + sortG[i].coutS + " mana");
            }
        }
    }

    public void afficheSortC(){
        for (int i = 0; i < 2; i++){
            if (sortC[i].coutS == 0){
                System.out.println((i+1) + " " +sortC[i].name);
            }
            else{
                System.out.println((i+1) + " " +sortC[i].name + " | " + sortC[i].coutS + " mana");
            }
        }
    }

    public void nourritureH(Hero heroN, Hero[] heroN2, Ennemy[] ennemiN){
        int getMana;
        Scanner manger = new Scanner(System.in);
        System.out.println("Que voulez-vous manger?");
        System.out.println("1) Cuisse de poulet");
        System.out.println("2) Raclette");
        int CR = manger.nextInt();
        if (CR == 1) {
            getMana = 5;
            if (getMana > heroN.manaMax - heroN.mana){
                heroN.manaMax = heroN.mana;
            }
            else{
                heroN.mana += getMana;
            }
        }
        else if (CR == 2){
            getMana = 10;
            heroN.mana += getMana;
            if (getMana > heroN.manaMax - heroN.mana){
                heroN.manaMax = heroN.mana;
            }
            else{
                heroN.mana += getMana;
            }
        }
        else{
            tourAl(heroN2, ennemiN);
        }
    }

    public void potionH(Hero heroP, Hero[] heroP2, Ennemy[] ennemiP){
        int getHeal;
        int effet;
        Scanner manger = new Scanner(System.in);
        System.out.println("Quelle potion voulez-vous utiliser?");
        System.out.println("1) Potion de vie");
        System.out.println("2) Potion de résistance");
        System.out.println("3) Potion de poison");
        System.out.println("4) Potion de guérison");
        System.out.println("5) Retour");
        int pot = manger.nextInt();

        if (pot == 1) {
            getHeal = 70;
            int al;
            Scanner lance2 = new Scanner(System.in);
            System.out.println("Sur qui voulez vous utiliser cette potion?");
            do{
                al = lance2.nextInt() - 1;
                if (al < nH){
                    if (heroP2[al].healthPoint == 0){
                        System.out.println(heroP.name + " est KO, veuillez en sélectionner un autre");
                    }
                    else if (heroP2[al].healthPoint == heroP2[al].healthPointMax){
                        System.out.println(heroP2[al].name + " a toute sa vie, veuillez en sélectionner un autre");
                    }
                }
            } while ((al >= nH) || (al < nH & heroP2[al].healthPoint == 0) || (al < nH & heroP2[al].healthPoint == heroP2[al].healthPointMax));
            System.out.println(heroP.name + " a lancé une potion de vie sur " + heroP2[al].name);
            if (getHeal > heroP.healthPointMax - heroP.healthPoint){
                System.out.println(heroP2[al].name + " a récupéré " + (heroP.healthPointMax - heroP.healthPoint) + " PV");
                heroP.healthPoint = heroP.healthPointMax;
            }
            else{
                System.out.println(heroP2[al].name + " a récupéré " + getHeal + " PV");
                heroP.healthPoint += getHeal;
            }
        }

        else if (pot == 2){
            int al;
            Scanner lance2 = new Scanner(System.in);
            System.out.println("Sur qui voulez vous utiliser cette potion?");
            do{
                al = lance2.nextInt() - 1;
                if (al < nH){
                    if (heroP2[al].healthPoint == 0){
                        System.out.println(heroP.name + " est KO, veuillez en sélectionner un autre");
                    }
                }
            } while ((al >= nH) || (al < nH & heroP2[al].healthPoint == 0));
            System.out.println(heroP.name + " a lancé une potion de résistance sur " + heroP2[al].name);
            heroP.resP = heroP.resP *2;;
            heroP.resS = heroP.resS *2;
        }

        else if (pot == 3) {
            effet = 5;
            int en;
            Scanner lance = new Scanner(System.in);
            System.out.println("Qui voulez-vous attaquer?");
            do {
                afficheEnnemies();
                en = lance.nextInt() - 1;
                if (en < nE) {
                    if (ennemiP[en].healthPoint == 0) {
                        System.out.println("Cet ennemi est KO, veuillez en sélectionner un autre");
                    }
                }
            }while ((en >= nE) || (ennemiP[en].healthPoint == 0));
            System.out.println(heroP.name + " lance une potion de poison sur " + ennemiP[en].name);
            ennemiP[en].effet += effet;
        }

        else if (pot == 4){
            int al;
            Scanner lance2 = new Scanner(System.in);
            System.out.println("Sur qui voulez vous utiliser cette potion?");
            do{
                al = lance2.nextInt() - 1;
                if (al < nH){
                    if (heroP2[al].healthPoint == 0){
                        System.out.println(heroP.name + " est KO, veuillez en sélectionner un autre");
                    }
                    else if (heroP2[al].effetS == 0){
                        System.out.println(heroP2[al].name + " n'a aucun symptôme, veuillez en sélectionner un autre");
                    }
                }
            } while ((al >= nH) || (al < nH & heroP2[al].healthPoint == 0) || (al < nH & heroP2[al].effetS == 0));
            System.out.println(heroP.name + " lance une potion de guérison sur " + heroP2[al].name);
            heroP2[al].effetS = 0;
        }

        else{
            tourAl(heroP2, ennemiP);
        }
    }

    public void etatAl(Hero[] heroEt){
        for (int i = 0; i < nH; i++){
            if (heroEt[i].effetP > heroEt[i].healthPoint){
                heroEt[i].healthPoint = 0;
            }
            else{
                heroEt[i].healthPoint -= heroEt[i].effetP;
            }
            heroEt[i].healthPoint -= heroEt[i].effetP;
        }
    }

    public void etatEn(Ennemy[] ennemiEt){
        for (int i = 0; i < nE; i++){
            if (ennemiEt[i].etat > ennemiEt[i].healthPoint){
                ennemiEt[i].healthPoint = 0;
            }
            else{
                ennemiEt[i].healthPoint -= ennemiEt[i].etat;
            }
        }
    }

    public void attaqueEn(Ennemy[] ennemiA){
        boolean verif;
        int qui;
        for (int i = 0; i < nE; i++){
            if (ennemiA[i].healthPoint != 0){
                Random who = new Random();
                do {
                    qui = who.nextInt(nH-1);
                    verif = verifHero(qui);
                } while (!verif); //Le héro est mort
                atEn(ennemiA[i], hero[qui]);
                if (hero[qui].healthPoint == 0){
                    System.out.println(hero[qui] + " est KO");
                }
            }
        }
        displayStatus();
    }

    public void atEn(Ennemy ennemiA2, Hero heroA2){
        int damageP = 0;
        int damageS = 0;
        Random atE = new Random();
        int attaqueE = 1 + atE.nextInt(4);
        if (ennemiA2.classe.equals("Dragon")){
            switch (attaqueE){
                case 1:
                    System.out.println(ennemiA2.name + " assaine un coup de griffes à " + heroA2.name + ".");
                    damageP = 15;
                    damageS = 0;
                    break;
                case 2:
                    System.out.println(ennemiA2.name + " mord " + heroA2.name + ".");
                    damageP = 15;
                    damageS = 0;
                    break;
                case 3:
                    System.out.println(ennemiA2.name + " brûle de ses flammes ardentes " + heroA2.name + ".");
                    damageP = 20;
                    damageS = 5;
                    heroA2.effetP += 5* heroA2.effetS;
                    break;
            }
        }
        else if (ennemiA2.classe.equals("Troll")){
            switch (attaqueE){
                case 1:
                    System.out.println(ennemiA2.name + " assaine un coup de poing à " + heroA2.name + ".");
                    damageP = 10;
                    damageS = 0;
                    break;
                case 2:
                    System.out.println(ennemiA2.name + " assaine un coup de massue à " + heroA2.name + ".");
                    damageP = 15;
                    damageS = 0;
                    break;
                case 3:
                    System.out.println(ennemiA2.name + " créé un séisme qui destabilise " + heroA2.name + ".");
                    damageP = 15;
                    damageS = 5;
                    heroA2.effetP += 5* heroA2.effetS;
                    break;
            }
        }
        else{
            switch (attaqueE){
                case 1:
                    System.out.println(ennemiA2.name + " lance une pioche sur " + heroA2.name + ".");
                    damageP = 5;
                    damageS = 0;
                    break;
                case 2:
                    System.out.println(ennemiA2.name + " assaine un coup de pioche à " + heroA2.name + ".");
                    damageP = 10;
                    damageS = 0;
                    break;
                case 3:
                    System.out.println(ennemiA2.name + " creuse un tunnel et fais tomber " + heroA2.name + " dedans.");
                    damageP = 10;
                    damageS = 0;
                    heroA2.effetP += 5* heroA2.effetS;
                    break;
            }
        }
        damageP = damageP*ennemiA2.damagePoints;
        damageS = damageS*ennemiA2.damagePoints;

        if ((heroA2.healthPoint < (damageP/ heroA2.resP))||(heroA2.healthPoint < (damageS/ heroA2.resS))){
            heroA2.healthPoint = 0;
        }
        else if(heroA2.healthPoint < ((damageP/ heroA2.resP) + (damageS/ heroA2.resS))){
            heroA2.healthPoint = 0;
        }
        else{
            heroA2.healthPoint -= ((damageP/ heroA2.resP) + (damageS/ heroA2.resS));
        }
    }

    public boolean verifHero(int qui){
        boolean VH = true;
        if (hero[qui].healthPoint == 0 ){
            VH = false;
        }
        return VH;
    }

    public void loot() throws InterruptedException {
        lootH();
        lootN();
        // lootP();
        lootB();
    }

    public void lootH(){
        for (int i = 0; i < nH; i++){
            if (hero[i].classe == "Hunter"){
                hero[i].arrow =  hero[i].arrowMax;
                System.out.println(hero[i].name + " a récupéré les flèches qu'il a envoyé...");
                System.out.println("Il a maintenant " + hero[i].arrow + " flèches dans son carquois");
            }
        }
    }

    public void lootP() throws InterruptedException {
        Random typeP = new Random();
        int type1 = 1 + typeP.nextInt(4);
        int type2 = 1 + typeP.nextInt(4);
        int total = type1 * 10 + type2;
        int use0 = potion[0].quantiteeM - potion[0].quantitee;
        int use1 = potion[1].quantiteeM - potion[1].quantitee;
        int use2 = potion[2].quantiteeM - potion[2].quantitee;
        int use3 = potion[3].quantiteeM - potion[3].quantitee;
        switch (total) {
            case 11:
                if (use0 > 2) {
                    System.out.println("Vous avez récupéré 2 potions de Vie");
                    potion[0].quantitee += 2;
                } else {
                    System.out.println("Vous avez trouvé 2 potions de Vie, malheureusement, vous n'avez pas assez de place");
                    System.out.println("Par conséquent, vous avez pu récupérer " + use0 + " potions de Vie");
                    potion[0].quantitee += use0;
                }
                break;

            case 12:
                System.out.println("Vous avez récupéré 1 potion de Vie et 1 potion de Résistance");
                if (use0 > 1 & use1 > 1) {
                    potion[0].quantitee += 1;
                    potion[1].quantitee += 1;
                } else if (use0 > 1 & use1 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Vie");
                    potion[0].quantitee += 1;
                } else if (use0 == 0 & use1 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Résistance");
                    potion[1].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 13:
                System.out.println("Vous avez récupéré 1 potion de Vie et 1 potion de Poison");
                if (use0 > 1 & use2 > 1) {
                    potion[0].quantitee += 1;
                    potion[2].quantitee += 1;
                } else if (use0 > 1 & use2 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Vie");
                    potion[0].quantitee += 1;
                } else if (use0 == 0 & use2 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Poison");
                    potion[2].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 14:
                System.out.println("Vous avez récupéré 1 potion de Vie et 1 potion de Guérison");
                if (use0 > 1 & use3 > 1) {
                    potion[0].quantitee += 1;
                    potion[3].quantitee += 1;
                } else if (use0 > 1 & use3 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Vie");
                    potion[0].quantitee += 1;
                } else if (use0 == 0 & use3 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Guérison");
                    potion[3].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;


            case 21:
                System.out.println("Vous avez récupéré 1 potion de Résistance et 1 potion de Vie");
                if (use0 > 1 & use1 > 1) {
                    potion[0].quantitee += 1;
                    potion[1].quantitee += 1;
                } else if (use0 > 1 & use1 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Vie");
                    potion[0].quantitee += 1;
                } else if (use0 == 0 & use1 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Résistance");
                    potion[1].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 22:
                if (use1 > 2) {
                    System.out.println("Vous avez récupéré 2 potions de Résistance");
                    potion[1].quantitee += 2;
                } else {
                    System.out.println("Vous avez trouvé 2 potions de Résistance, malheureusement, vous n'avez pas assez de place");
                    System.out.println("Par conséquent, vous avez pu récupérer " + use1 + " potions de Résistance");
                    potion[1].quantitee += use1;
                }
                break;

            case 23:
                System.out.println("Vous avez récupéré 1 potion de Résistance et 1 potion de Poison");
                if (use1 > 1 & use2 > 1) {
                    potion[1].quantitee += 1;
                    potion[2].quantitee += 1;
                } else if (use2 > 1 & use1 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Poison");
                    potion[2].quantitee += 1;
                } else if (use2 == 0 & use1 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Résistance");
                    potion[1].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 24:
                System.out.println("Vous avez récupéré 1 potion de Résistance et 1 potion de Guérison");
                if (use3 > 1 & use1 > 1) {
                    potion[3].quantitee += 1;
                    potion[1].quantitee += 1;
                } else if (use3 > 1 & use1 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Guérison");
                    potion[3].quantitee += 1;
                } else if (use3 == 0 & use1 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Résistance");
                    potion[1].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;


            case 31:
                System.out.println("Vous avez récupéré 1 potion de Poison et 1 potion de Vie");
                if (use0 > 1 & use2 > 1) {
                    potion[0].quantitee += 1;
                    potion[2].quantitee += 1;
                } else if (use0 > 1 & use2 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Vie");
                    potion[0].quantitee += 1;
                } else if (use0 == 0 & use2 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Poison");
                    potion[2].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 32:
                System.out.println("Vous avez récupéré 1 potion de Poison et 1 potion de Résistance");
                if (use1 > 1 & use2 > 1) {
                    potion[1].quantitee += 1;
                    potion[2].quantitee += 1;
                } else if (use2 > 1 & use1 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Poison");
                    potion[2].quantitee += 1;
                } else if (use2 == 0 & use1 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Résistance");
                    potion[1].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 33:
                if (use2 > 2) {
                    System.out.println("Vous avez récupéré 2 potions de Poison");
                    potion[2].quantitee += 2;
                } else {
                    System.out.println("Vous avez trouvé 2 potions de Résistance, malheureusement, vous n'avez pas assez de place");
                    System.out.println("Par conséquent, vous avez pu récupérer " + use2 + " potions de Résistance");
                    potion[2].quantitee += use2;
                }
                break;

            case 34:
                System.out.println("Vous avez récupéré 1 potion de Poison et 1 potion de Guérison");
                if (use3 > 1 & use2 > 1) {
                    potion[3].quantitee += 1;
                    potion[2].quantitee += 1;
                } else if (use2 > 1 & use3 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Poison");
                    potion[2].quantitee += 1;
                } else if (use2 == 0 & use3 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Guérison");
                    potion[3].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 41:
                System.out.println("Vous avez récupéré 1 potion de Guérison et 1 potion de Vie");
                if (use0 > 1 & use3 > 1) {
                    potion[0].quantitee += 1;
                    potion[3].quantitee += 1;
                } else if (use0 > 1 & use3 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Vie");
                    potion[0].quantitee += 1;
                } else if (use0 == 0 & use3 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Guérison");
                    potion[3].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 42:
                System.out.println("Vous avez récupéré 1 potion de Guérison et 1 potion de Résistance");
                if (use3 > 1 & use1 > 1) {
                    potion[3].quantitee += 1;
                    potion[1].quantitee += 1;
                } else if (use3 > 1 & use1 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Guérison");
                    potion[3].quantitee += 1;
                } else if (use3 == 0 & use1 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Résistance");
                    potion[1].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 43:
                System.out.println("Vous avez récupéré 1 potion de Guérison et 1 potion de Poison");
                if (use2 > 1 & use3 > 1) {
                    potion[2].quantitee += 1;
                    potion[3].quantitee += 1;
                } else if (use2 > 1 & use3 == 0) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Poison");
                    potion[2].quantitee += 1;
                } else if (use2 == 0 & use3 > 1) {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous avez donc récupéré la potion de Guérison");
                    potion[3].quantitee += 1;
                } else {
                    System.out.println("Malheureusement, vous n'avez pas assez de place, vous n'avez donc rien récupéré");
                }
                break;

            case 44:
                System.out.println("Vous avez récupéré 2 potions de Guérison");
                if (use3 > 2) {
                    System.out.println("Vous avez récupéré 2 potions de Poison");
                    potion[3].quantitee += 2;
                } else {
                    System.out.println("Vous avez trouvé 2 potions de Résistance, malheureusement, vous n'avez pas assez de place");
                    System.out.println("Par conséquent, vous avez pu récupérer " + use3 + " potions de Résistance");
                    potion[3].quantitee += use3;
                }
                break;
        }
    }

    public void lootN() throws InterruptedException {
        int cu = food[0].quantiteeM - food[0].quantitee;
        int ra = food[1].quantiteeM - food[1].quantitee;
        if (cu < 5){
            food[0].quantitee = food[0].quantiteeM;
            System.out.println("Vous avez récupéré " + cu + " cuisses de Poulet");
        }
        else{
            food[0].quantitee += 5;
            System.out.println("Vous avez récupéré 5 cuisses de Poulet");
        }

        if (ra < 2){
            food[1].quantitee = food[1].quantiteeM;
            System.out.println("Vous avez récupéré " + ra + " portion de Raclette");
        }
        else{
            food[0].quantitee += 5;
            System.out.println("Vous avez récupéré 2 portion de Raclette");
        }
    }

    public void lootB(){
        Random obj = new Random();
        int nbObjet = obj.nextInt(4);
        int typeO = obj.nextInt(5);
        for (int i = 0; i < nbObjet; i++){
            switch (nbObjet){
                case 0:
                    System.out.println("Vous fouillez un ennemi et vous avez trouvé une PokeBall... ");
                    System.out.println("il était sûrement à la recherche de Mew...");
                    break;
                case 1:
                    System.out.println("Vous fouillez un ennemi et vous avez trouvé une Toupie Beyblade... pas très utile en combat");
                    break;
                case 2:
                    System.out.println("Vous fouillez un ennemi et vous avez trouvé du papier toilette...");
                    System.out.println("il devait avoir une envie pressante...");
                    break;
                case 3:
                    System.out.println("Vous fouillez un ennemi et vous avez trouvé un Iphone...");
                    System.out.println("La dernière photo prise est une photo de lui vous attaquant... quel arrogance.");
                    break;
                case 4:
                    System.out.println("Vous fouillez un ennemi et vous avez trouvé la carte du Maraudeur...");
                    System.out.println("Il s'est cru dans Harry Potter ou quoi...");
                    break;
                case 5:
                    System.out.println("Vous fouillez un ennemi et vous avez trouvé une paire de lunette...");
                    System.out.println("Ça doit être pour ça qu'il n'a pas réussi à vous toucher...");
                    break;
            }
        }
    }

    public void experience(){
        for (int i = 0; i < nH; i++){
            Random exper = new Random();
            int exp = exper.nextInt(2);
            switch (exp){
                case 0:
                    hero[i].healthPointMax += 10;
                    System.out.println("Les HP de " + hero[i].name + " sont passées de " + (hero[i].healthPointMax - 5) + " à " + hero[i].healthPointMax);
                    if (hero[i].healthPoint == 0){
                        hero[i].healthPoint = 0;
                    }
                    else{
                        hero[i].healthPoint += 10;
                        System.out.println(hero[i].name + " a récupéré 10 HP");
                    }
                    break;
                case 1:
                    hero[i].manaMax += 2;
                    System.out.println("L'énergie de " + hero[i].name + " sont passées de " + (hero[i].manaMax - 2) + " à " + hero[i].manaMax);
                    if (hero[i].mana == 0){
                        hero[i].mana = 0;
                    }
                    else{
                        hero[i].mana += 2;
                        System.out.println(hero[i].name + " a récupéré 2 Mana");
                    }
                    break;
                case 2:
                    System.out.println("Les résistances de " + hero[i].name + " ont augmenté");
                    hero[i].resP += 1;
                    hero[i].resS += 1;
                    break;
            }
        }

    }

    public void finJeu() throws InterruptedException {
        System.out.println("Merci d'avoir joué à notre jeu.");
        TimeUnit.SECONDS.sleep(1);
        System.out.println("J'espère vous revoir bientôt jeune aventurier.");
    }

    public static void displayMessage(String message) {
        System.out.println(message);
    }
}