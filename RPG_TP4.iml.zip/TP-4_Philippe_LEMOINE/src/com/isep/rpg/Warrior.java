package com.isep.rpg;

public class Warrior extends Hero{

    public Warrior(String n) {
        super(n);
        this.healthPoint = 100;
        healthPointMax = 100;
        this.mana = 3;
        manaMax = 3;
        this.resS = 1;
        this.cout = 1;
        this.recupM = 0;
        this.recupV = 0;
        this.effetS = 1;
        effetP = 0;
        this.degP = 2;
        this.resP = 2;
        arrow = 0;
        arrowMax = 0;
        classe = "Warrior";
    }
    @Override
    public void fight (Combattant combattant){
        combattant.loose(weapon.getDamagePoints());
    }

    @Override
    public void take(Item item) {
        if (item instanceof Weapon) {
            weapon = (Weapon) item;
        }
        else {
            Game.displayMessage("Oups ! " + item.getName() + " est inutile...");
        }
    }
}
