package com.isep.rpg;

public class CuisseP extends Food{
    public CuisseP(String name) {
        super(name);
        int mana = 5;
        this.mana = mana;
        quantitee = 20;
        quantiteeM = 20;
    }
}
