package com.isep.rpg;

public abstract class Combattant {
    public Combattant(String n){
        name = n;
    }

    public String getName(){return name;}
    public int getHealthPoint(){return healthPoint;}

    public int loose (int hp){
        if (healthPoint >= hp){
            healthPoint -= hp;
        }
        else{
            healthPoint = 0;
        }
        return healthPoint;
    }

    public abstract void fight(Combattant combattant);

    public static String name;
    private int healthPoint;
}
